import org.json.JSONObject
import scalaj.http.{Http, HttpOptions, HttpResponse}

import scala.io.Source
import scala.util.control.NonFatal

object ReadJson extends App {
  val filename = args.head
  Source.fromFile(filename).getLines().toList.foreach(j=>{
    val jsonObject = new JSONObject(j)
    val s = s"http://localhost:11111/v1/cc/api/convertCurrency/${args(1)}"
    try {
    val result:HttpResponse[String] = Http(s"http://localhost:11111/v1/cc/api/convertCurrency/${args(1)}").postData(j)
        .header("Content-Type", "application/json")
        .header("Charset", "UTF-8")
        .option(HttpOptions.readTimeout(10000)).asString
  println(result.body)
    } catch {
      case NonFatal(e) => throw new Exception(e.getMessage)
    }
  })

}
